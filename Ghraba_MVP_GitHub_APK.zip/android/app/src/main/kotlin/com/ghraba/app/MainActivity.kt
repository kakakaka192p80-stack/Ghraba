package com.ghraba.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
