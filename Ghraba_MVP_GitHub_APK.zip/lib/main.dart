import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = InvoiceStore();
  await store.load();
  runApp(GhrabaApp(store: store));
}

enum InvoiceStatus { nonRecue, decharge, facturee }

extension InvoiceStatusX on InvoiceStatus {
  String get label => switch (this) {
        InvoiceStatus.nonRecue => 'Non reçue',
        InvoiceStatus.decharge => 'Décharge',
        InvoiceStatus.facturee => 'Facturée',
      };

  Color get color => switch (this) {
        InvoiceStatus.nonRecue => Colors.orange,
        InvoiceStatus.decharge => Colors.blue,
        InvoiceStatus.facturee => Colors.green,
      };
}

class Invoice {
  Invoice({
    required this.id,
    required this.number,
    required this.supplier,
    required this.amount,
    required this.date,
    this.dueDate,
    required this.status,
    this.notes = '',
    this.hasDocument = false,
    this.hasDecharge = false,
  });

  final String id;
  String number;
  String supplier;
  double amount;
  DateTime date;
  DateTime? dueDate;
  InvoiceStatus status;
  String notes;
  bool hasDocument;
  bool hasDecharge;
}

class InvoiceStore extends ChangeNotifier {
  final List<Invoice> invoices = [];
  late SharedPreferences _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final saved = _prefs.getStringList('invoice_demo');
    if (saved == null || saved.isEmpty) {
      invoices.addAll([
        Invoice(
          id: '1',
          number: 'F2026-001',
          supplier: 'Fournisseur ABC',
          amount: 1250,
          date: DateTime(2026, 10, 1),
          status: InvoiceStatus.nonRecue,
          hasDocument: true,
        ),
        Invoice(
          id: '2',
          number: 'F2026-002',
          supplier: 'Société Tunisienne',
          amount: 850,
          date: DateTime(2026, 9, 27),
          status: InvoiceStatus.decharge,
          hasDocument: true,
          hasDecharge: true,
        ),
        Invoice(
          id: '3',
          number: 'F2026-003',
          supplier: 'Services Plus',
          amount: 560,
          date: DateTime(2026, 9, 22),
          status: InvoiceStatus.facturee,
          hasDocument: true,
          hasDecharge: true,
        ),
        Invoice(
          id: '4',
          number: 'F2026-004',
          supplier: 'Techno SARL',
          amount: 320,
          date: DateTime(2026, 9, 18),
          status: InvoiceStatus.facturee,
        ),
      ]);
    } else {
      for (final row in saved) {
        final p = row.split('|');
        if (p.length >= 9) {
          invoices.add(Invoice(
            id: p[0],
            number: p[1],
            supplier: p[2],
            amount: double.tryParse(p[3]) ?? 0,
            date: DateTime.tryParse(p[4]) ?? DateTime.now(),
            dueDate: p[5].isEmpty ? null : DateTime.tryParse(p[5]),
            status: InvoiceStatus.values[int.tryParse(p[6]) ?? 0],
            notes: p[7],
            hasDocument: p[8] == '1',
            hasDecharge: p.length > 9 && p[9] == '1',
          ));
        }
      }
    }
  }

  Future<void> persist() async {
    await _prefs.setStringList(
      'invoice_demo',
      invoices.map((i) => [
        i.id, i.number, i.supplier, i.amount.toString(), i.date.toIso8601String(),
        i.dueDate?.toIso8601String() ?? '', i.status.index.toString(), i.notes,
        i.hasDocument ? '1' : '0', i.hasDecharge ? '1' : '0'
      ].join('|')).toList(),
    );
  }

  Future<void> add(Invoice invoice) async {
    invoices.insert(0, invoice);
    await persist();
    notifyListeners();
  }

  Future<void> setStatus(Invoice invoice, InvoiceStatus status) async {
    invoice.status = status;
    if (status == InvoiceStatus.decharge || status == InvoiceStatus.facturee) {
      invoice.hasDecharge = true;
    }
    await persist();
    notifyListeners();
  }

  double get total => invoices.fold(0, (s, i) => s + i.amount);
  int count(InvoiceStatus s) => invoices.where((i) => i.status == s).length;
}

class GhrabaApp extends StatelessWidget {
  const GhrabaApp({super.key, required this.store});
  final InvoiceStore store;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ghraba',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF146EF5),
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
        ),
      ),
      home: HomeShell(store: store),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.store});
  final InvoiceStore store;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(store: widget.store),
      InvoiceListPage(store: widget.store),
      const ReportsPage(),
      const SettingsPage(),
    ];
    return AnimatedBuilder(
      animation: widget.store,
      builder: (_, __) => Scaffold(
        body: pages[index],
        floatingActionButton: FloatingActionButton(
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AddInvoicePage(store: widget.store),
              ),
            );
          },
          child: const Icon(Icons.add),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Factures'),
            NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Rapports'),
            NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz), label: 'Plus'),
          ],
        ),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key, required this.title, this.subtitle});
  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey.shade600)),
          ],
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.store});
  final InvoiceStore store;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          const AppHeader(title: 'Ghraba', subtitle: 'Bonjour Ibrahim 👋 — votre suivi des factures'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.55,
              children: [
                StatCard(title: 'Total factures', value: '${store.invoices.length}', icon: Icons.receipt_long, color: Colors.blue),
                StatCard(title: 'Non reçues', value: '${store.count(InvoiceStatus.nonRecue)}', icon: Icons.pending_actions, color: Colors.orange),
                StatCard(title: 'Décharge', value: '${store.count(InvoiceStatus.decharge)}', icon: Icons.description, color: Colors.indigo),
                StatCard(title: 'Facturées', value: '${store.count(InvoiceStatus.facturee)}', icon: Icons.check_circle, color: Colors.green),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Montant total', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text('${store.total.toStringAsFixed(3)} TND', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 18),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: store.invoices.isEmpty ? 0 : store.count(InvoiceStatus.facturee) / store.invoices.length,
                      minHeight: 10,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('Progression des factures facturées'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text('Dernières factures', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ),
          ...store.invoices.take(4).map((i) => InvoiceTile(invoice: i, store: store)),
        ],
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value, required this.icon, required this.color});
  final String title, value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color),
            const Spacer(),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            Text(title, style: TextStyle(color: Colors.grey.shade600)),
          ],
        ),
      ),
    );
  }
}

class InvoiceListPage extends StatefulWidget {
  const InvoiceListPage({super.key, required this.store});
  final InvoiceStore store;

  @override
  State<InvoiceListPage> createState() => _InvoiceListPageState();
}

class _InvoiceListPageState extends State<InvoiceListPage> {
  String query = '';
  InvoiceStatus? filter;

  @override
  Widget build(BuildContext context) {
    final rows = widget.store.invoices.where((i) {
      final q = query.toLowerCase();
      final matchesText = i.number.toLowerCase().contains(q) || i.supplier.toLowerCase().contains(q);
      final matchesStatus = filter == null || i.status == filter;
      return matchesText && matchesStatus;
    }).toList();

    return SafeArea(
      child: Column(
        children: [
          const AppHeader(title: 'Factures', subtitle: 'Recherche et suivi des statuts'),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher une facture...'),
              onChanged: (v) => setState(() => query = v),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                FilterChip(label: const Text('Toutes'), selected: filter == null, onSelected: (_) => setState(() => filter = null)),
                const SizedBox(width: 8),
                ...InvoiceStatus.values.map((s) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(label: Text(s.label), selected: filter == s, onSelected: (_) => setState(() => filter = s)),
                )),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: rows.isEmpty
                ? const Center(child: Text('Aucune facture trouvée'))
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 100),
                    itemCount: rows.length,
                    itemBuilder: (_, idx) => InvoiceTile(invoice: rows[idx], store: widget.store),
                  ),
          ),
        ],
      ),
    );
  }
}

class InvoiceTile extends StatelessWidget {
  const InvoiceTile({super.key, required this.invoice, required this.store});
  final Invoice invoice;
  final InvoiceStore store;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: invoice.status.color.withOpacity(.12),
          child: Icon(Icons.receipt_long, color: invoice.status.color),
        ),
        title: Text(invoice.number, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${invoice.supplier}\n${invoice.amount.toStringAsFixed(3)} TND'),
        isThreeLine: true,
        trailing: StatusChip(status: invoice.status),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => InvoiceDetailPage(invoice: invoice, store: store)),
        ),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.status});
  final InvoiceStatus status;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: status.color.withOpacity(.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(status.label, style: TextStyle(color: status.color, fontWeight: FontWeight.bold, fontSize: 11)),
    );
  }
}

class AddInvoicePage extends StatefulWidget {
  const AddInvoicePage({super.key, required this.store});
  final InvoiceStore store;

  @override
  State<AddInvoicePage> createState() => _AddInvoicePageState();
}

class _AddInvoicePageState extends State<AddInvoicePage> {
  final formKey = GlobalKey<FormState>();
  final number = TextEditingController();
  final supplier = TextEditingController();
  final amount = TextEditingController();
  final notes = TextEditingController();
  InvoiceStatus status = InvoiceStatus.nonRecue;
  DateTime date = DateTime.now();
  bool hasDocument = false;

  @override
  void dispose() {
    number.dispose();
    supplier.dispose();
    amount.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    await widget.store.add(Invoice(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      number: number.text.trim(),
      supplier: supplier.text.trim(),
      amount: double.parse(amount.text.replaceAll(',', '.')),
      date: date,
      status: status,
      notes: notes.text.trim(),
      hasDocument: hasDocument,
    ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajouter une facture')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: number, decoration: const InputDecoration(labelText: 'Numéro de facture *'), validator: (v) => v == null || v.trim().isEmpty ? 'Champ obligatoire' : null),
            const SizedBox(height: 12),
            TextFormField(controller: supplier, decoration: const InputDecoration(labelText: 'Fournisseur / Client *'), validator: (v) => v == null || v.trim().isEmpty ? 'Champ obligatoire' : null),
            const SizedBox(height: 12),
            TextFormField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Montant (TND) *'), validator: (v) {
              final n = double.tryParse((v ?? '').replaceAll(',', '.'));
              return n == null || n < 0 ? 'Montant invalide' : null;
            }),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Date de facture'),
              subtitle: Text('${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}'),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final d = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: date);
                if (d != null) setState(() => date = d);
              },
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<InvoiceStatus>(
              value: status,
              decoration: const InputDecoration(labelText: 'Statut'),
              items: InvoiceStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(s.label))).toList(),
              onChanged: (v) => setState(() => status = v ?? InvoiceStatus.nonRecue),
            ),
            const SizedBox(height: 12),
            TextFormField(controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'Notes')),
            const SizedBox(height: 12),
            Card(
              child: SwitchListTile(
                title: const Text('Document joint'),
                subtitle: const Text('MVP: indicateur local, upload réel à connecter à Supabase Storage'),
                value: hasDocument,
                onChanged: (v) => setState(() => hasDocument = v),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('Enregistrer')),
          ],
        ),
      ),
    );
  }
}

class InvoiceDetailPage extends StatelessWidget {
  const InvoiceDetailPage({super.key, required this.invoice, required this.store});
  final Invoice invoice;
  final InvoiceStore store;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Détail de la facture')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(invoice.number, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(invoice.supplier),
                  const SizedBox(height: 16),
                  Text('${invoice.amount.toStringAsFixed(3)} TND', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  StatusChip(status: invoice.status),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(title: const Text('Date'), trailing: Text('${invoice.date.day}/${invoice.date.month}/${invoice.date.year}')),
                ListTile(title: const Text('Document'), trailing: Icon(invoice.hasDocument ? Icons.check_circle : Icons.remove_circle, color: invoice.hasDocument ? Colors.green : Colors.grey)),
                ListTile(title: const Text('Décharge'), trailing: Icon(invoice.hasDecharge ? Icons.check_circle : Icons.remove_circle, color: invoice.hasDecharge ? Colors.green : Colors.grey)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (invoice.notes.isNotEmpty)
            Card(child: ListTile(title: const Text('Notes'), subtitle: Text(invoice.notes))),
          const SizedBox(height: 12),
          Text('Changer le statut', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...InvoiceStatus.values.map((s) => Card(
            child: RadioListTile<InvoiceStatus>(
              value: s,
              groupValue: invoice.status,
              title: Text(s.label),
              activeColor: s.color,
              onChanged: (v) async {
                if (v != null) await store.setStatus(invoice, v);
              },
            ),
          )),
        ],
      ),
    );
  }
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.findAncestorStateOfType<_HomeShellState>()?.widget.store;
    if (store == null) return const Center(child: Text('Rapports'));
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          const AppHeader(title: 'Rapports', subtitle: 'Vue synthétique des factures'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total', style: Theme.of(context).textTheme.titleMedium),
                  Text('${store.invoices.length} factures', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Text('Montant total'),
                  Text('${store.total.toStringAsFixed(3)} TND', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 20),
                  ...InvoiceStatus.values.map((s) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Row(
                      children: [
                        Expanded(child: Text(s.label)),
                        Text('${store.count(s)}'),
                      ],
                    ),
                  )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          const AppHeader(title: 'Paramètres', subtitle: 'Configuration de Ghraba'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: const [
                ListTile(leading: Icon(Icons.person), title: Text('Mon profil'), subtitle: Text('Ibrahim')),
                Divider(height: 1),
                ListTile(leading: Icon(Icons.business), title: Text('Organisation'), subtitle: Text('Société ABC')),
                Divider(height: 1),
                ListTile(leading: Icon(Icons.notifications), title: Text('Notifications'), subtitle: Text('À connecter en production')),
                Divider(height: 1),
                ListTile(leading: Icon(Icons.cloud), title: Text('Sauvegarde Cloud'), subtitle: Text('Supabase prévu pour la V1')),
                Divider(height: 1),
                ListTile(leading: Icon(Icons.language), title: Text('Langue'), subtitle: Text('Français')),
                Divider(height: 1),
                ListTile(leading: Icon(Icons.info_outline), title: Text('À propos'), subtitle: Text('Ghraba MVP 1.0.0')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
