create extension if not exists pgcrypto;

create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  address text,
  logo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists organization_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  user_id uuid not null,
  role text not null default 'USER'
    check (role in ('ADMIN','MANAGER','USER','VIEWER')),
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  code text,
  phone text,
  email text,
  address text,
  tax_id text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  invoice_number text not null,
  supplier_id uuid references suppliers(id) on delete set null,
  amount numeric(14,3) not null default 0,
  currency text not null default 'TND',
  invoice_date date not null default current_date,
  due_date date,
  status text not null default 'NON_RECUE'
    check (status in ('NON_RECUE','DECHARGE','FACTUREE')),
  notes text,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, invoice_number)
);

create table if not exists invoice_documents (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete cascade,
  document_type text not null check (document_type in ('INVOICE','DECHARGE','OTHER')),
  file_name text not null,
  file_path text not null,
  mime_type text,
  file_size bigint,
  uploaded_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists invoice_status_history (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete cascade,
  old_status text,
  new_status text not null,
  changed_by uuid,
  comment text,
  created_at timestamptz not null default now()
);

create index if not exists idx_invoices_org_status
  on invoices(organization_id, status);

create index if not exists idx_invoices_date
  on invoices(invoice_date);

create index if not exists idx_suppliers_org
  on suppliers(organization_id);
