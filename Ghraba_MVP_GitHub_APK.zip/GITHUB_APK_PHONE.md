# Ghraba — بناء APK من الهاتف عبر GitHub

1. افتح GitHub وأنشئ مستودعاً جديداً باسم `ghraba`.
2. ارفع ملفات هذا المشروع كاملة، وخاصة مجلد `.github`.
3. افتح تبويب **Actions**.
4. اختر **Build Android APK**.
5. اضغط **Run workflow** إذا لم يبدأ البناء تلقائياً.
6. بعد نجاح البناء افتح العملية.
7. من **Artifacts** اضغط **ghraba-apk**.
8. فك ملف ZIP وستجد `app-release.apk`.
9. افتح APK على هاتف Android وثبّته.

لا تحتاج إلى Flutter أو Android Studio على الهاتف؛ GitHub Actions يقوم بالبناء على السحابة.

ملاحظة: هذه نسخة MVP محلية. الربط الحقيقي مع Supabase ورفع ملفات الفواتير يحتاج مرحلة لاحقة.
